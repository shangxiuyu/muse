## 🟡 流派一：Neo-Memphis Toy Blocks (乐高积木与波普多巴胺流)

### 1. 审美隐喻与气质
* **视觉标杆**：GitHub 开源 `slidevjs/themes (bricks)`、Figma Config 玩味舞台、乐高创意工坊。
* **情绪与气质**：活力四射、多巴胺爆发、童趣高亲和力、打破严肃与冰冷。
* **核心排版手艺**：
  * **玩具积木拼接**：卡片带有明显的 3px 实心纯黑硬描边与 5px 纯黑偏置阴影（Offset Shadow）。
  * **微倾斜胶带与徽章**：关键标签微倾斜（-2° ~ 1.5°），模拟贴纸与实物玩具。
  * **高对比色块撞色**：高饱和明黄为底，配合天空蓝、樱花粉、薄荷绿三色卡片并列。

> **本流派的纯黑用法（表层偏离已声明）**：3px 描边与 5px 偏置阴影用纯黑，是积木玩具的形式语言——硬描边换任何深灰都会失去塑料玩具的实心感。纯黑**只作线、边框与影子，从不作页面底盘**；底盘始终是高饱和明黄。按 SKILL.md 的〈底线与例外〉，此偏离在此显式声明。

<!-- muse:allow pure-black: Neo-Memphis 玩具积木流以 3px 纯黑硬描边与 5px 纯黑偏置阴影为形式语言——硬描边改深灰会失去塑料玩具的实心感；纯黑只作线与影，不作底盘（底盘为高饱和明黄 #fef08a） -->

### 2. 精确 Design Tokens
```css
/* Bricks & Neo-Memphis Tokens */
--bg-bricks: #fef08a; /* 亮柠檬暖黄 */
--bg-dot-pattern: #eab308; /* 网格点纹理 */
--border-black: 3px solid #000000;
--shadow-hard: 5px 5px 0px #000000;
--card-blue: #38bdf8;
--card-pink: #f472b6;
--card-green: #4ade80;
--font-headline: 'Fredoka', 'Comic Neue', cursive, sans-serif; /* 仅拉丁：中文标题无手写对应字体 */
--font-body: 'Plus Jakarta Sans', 'PingFang SC', sans-serif;
```

### 3. 标准页型与结构模式（范式，非模板）
* **Cover (立意封面)**：大字粗体描边标题（`-webkit-text-stroke: 1.5px #000` + `text-shadow: 4px 4px 0px #38bdf8`），上方贴红色圆形胶囊药丸徽章。
* **Cards Row (积木并列)**：蓝、粉、绿积木卡片错落排列（**错落，不是等宽三等分**），每张卡片带大号物理图标与粗黑边框。
* **Data Impact (数据突破)**：左侧大号纯白硬框展示大字成就（如 `10/10`），右侧配放大气泡名言。

### 4. 最佳应用场景
* 黑客松（Hackathon）项目路演、产品创意脑暴、设计冲刺（Design Sprint）复盘、新员工文化欢迎会、教育与青年创意提案。

---

## 🈶 演示端中文配对 (CJK Pairing)

> **为什么演示端也要这一层**：6.0 给 10 个母体补[中文排版基线](../../archetypes.md)时漏了演示分支——本库原来 7 个字体栈里没有任何中文字体。中文演示是默认场景，字体栈没有 CJK 就会让浏览器 fallback 决定字形，中文标题与正文的节奏会全线失守。**每个流派落地前，先按本节补 CJK 字体栈。**

### 三条硬规则（与主基线一致）

1. **中文字体必须显式写进字体栈**，拉丁在前、CJK 在后。
2. **负字距只作用于拉丁**。[演示手册](../presentation_tool.md)要求的 `-0.03em ~ -0.05em` Display 标题字距，**用在中文标题上会挤压字形**；中文大标题改用零或正字距。
3. **`text-transform: uppercase` 对中文无效**。本库流派三的「大写字距签名」与流派四/五的等宽大写标签，中文改由加宽字距、加粗或方括号承载。

### 与各流派的 CJK 配对

| 流派 | 拉丁字体（流派原生） | 建议 CJK 配对 | 中文要特别注意 |
| :--- | :--- | :--- | :--- |
| 一 · 乐高积木多巴胺 | Fredoka / Comic Neue / Plus Jakarta Sans | 正文 → `PingFang SC`；**标题无配对** | 手写圆体没有中文对应字体，中文封面别指望 Fredoka 的玩味；改用超大字号 + 描边 + 倾斜来承载同一意图 |
| 二 · 麦肯锡商务深蓝 | Plus Jakarta Sans / Inter | `Noto Sans SC` | 行动导向标题是长句，中文长句在 36pt 下容易换行失控，收敛到 28–32pt 并缩短论断 |
| 三 · 燕麦画廊高奢刊物 | Newsreader / Lora（衬线） | 衬线 → `Songti SC` / `Noto Serif SC`；元信息 → `PingFang SC` | 中文衬线在小字上会糊，宋体只留给 18px 以上的金句；微文案（书眉、签名）走黑体 |
| 四 · 科技旗舰发布 | Geist / Geist Mono | `PingFang SC`；等宽处 → `Noto Sans Mono` | 等宽中文是最容易翻车的组合——`9.2ms` 这类指标用等宽拉丁，中文标签换回无衬线 |
| 五 · 精密工装职场研报 | IBM Plex Sans / Geist Mono | `Noto Sans SC`；等宽处 → `Noto Sans Mono` | 中文正文在 `#F8FAFC` 微网格底上对比度衰减更快，正文降到 `#334155` 一级；等宽只留给拉丁数字 |

### 验收时必看

按[成品验收](../../acceptance_protocol.md)检查中文：**真实中文段落**（不是 Lorem Ipsum 或英文占位）、长短标题、中英混排、数字与标点、200% 文字缩放、投影尺寸下的可读性。**只看英文样例就宣布演示排版通过，是无效验收。**

---