# 一块咖啡 · 品牌介绍 · 源文件包

导出版本：1

打开 index.html 查看作品；演示支持方向键翻页与全屏。

- source/artifact.json：当前作品的原始内容与版本信息。
- source/slides.json：逐页内容、原始 HTML 和讲者备注。source/slides/：可单独打开与编辑的页面。speaker-notes.md：完整讲者备注。index.html 为导出时的演示快照，单页修改不会自动同步到它。
- design-system/：实际样式、设计变量清单、创作方向与关联设计规范。
- manifest.json：版本信息和文件列表。

源文件保留原始内容与内嵌资源。外部链接、字体或图片仍保留其引用，离线可用性取决于原作品；未另行下载远程资源。
